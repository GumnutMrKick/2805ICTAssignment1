
package minesweeperprototype;

import java.util.Date;
import java.util.Random;
import java.util.LinkedList;
import java.awt.Point;

/**
 * (c) 2020 Vlad Estivill-Castro
 * Model Solution for 2017-2018-2019 Assignment
 * 2805ICT/3815ICT/7805ICT Principles of Software Engineering / Design of Object Oriented Systems
 *
 * Class that works as the current model of the Minesweeper game.
 * It is intended that this class or a generalisation of it plays the
 * role of the Model in the architectural pattern MVC.
 * @author vlad estivill-castro
 */
public class GlobalModel {
    
    /**
    * The enum that defines the difficulty levels and offers type conversion
    * formats to obtain the enum given the integer ordinal and the inverse.
    * We also use the names in the enum to generate the GUI-Item Menu entries
    * and to iterate to populate a menu.
    */
    public enum DifficultyLevels {
        NOVICE(0),
        COMPETENT(1),
        EXPERT(2);
        public int value;
        private DifficultyLevels(int value) {
                this.value = value;
        }
    }
    
    /**
    * The enum that defines the environments and offers type conversion
    * formats to obtain the enum given the integer ordinal and the inverse.
    */
       public enum Environments {
        SQUARE(0),
        HEXAGONAL(1),
        TOPOLOGICAL(2);
        private int value;
        private Environments(int value) {
                this.value = value;
        }
    }
    
    /**
    * Constant that defines the amount of mines in an environment.
    * It is a percentage of the available cells in a squared grid.
    */
    private static final int DENSITY_PERCENTAGE=20; 
    
    private DifficultyLevels theLevel;
    private Environments environment;
    
    private static final int thedimension[]={10,15,20};
    
    private long  the_seed;
    private Random rand;
    
    private int x_dimension;
    private int y_dimension;
    
    private  int   square_board[][];
    private  boolean   square_is_covered[][];
    private int total_num_mines;
    /**
     *  During the game the active mines decrease by replacing the -1 in the board
     */
    
    /** 
    * Class constructor where the parameters set defaults for
    * level = NOVICE and environment is square grid.
    */
    public GlobalModel()
		{  this(DifficultyLevels.NOVICE,Environments.SQUARE);
                }
    
    /** 
    * Class constructor that allows parameters
    * It also secure a random seed by using milliseconds in the current time
    * of the system.
    * @param aLevel the level to set to.
    * @param anEnvironment the chosen level, for instance: square grid
    */
    public GlobalModel(DifficultyLevels aLevel,
            Environments anEnvironment
                       )
		{   the_seed = (new Date().getTime())%10000;
                    //the_seed=0; // for testing determinsitic
                   rand= new Random(the_seed);
                   theLevel= aLevel;
                   environment=anEnvironment;
                   set_Board(theLevel);
                }

    /** 
    * Initialise the environment populating it with mines.
    * @param the difficulty level, this determines the size of the environment
    * because it defines the number of vertical cells. This is the y_dimension.
    * The x_dimension is always 50% more then the y_dimension.
    */
    private void set_Board(DifficultyLevels aLevel){
        // to view landscape rather than portrait
        y_dimension = thedimension[aLevel.value];
        x_dimension = thedimension[aLevel.value] + thedimension[aLevel.value]/2;
        square_board = new int [x_dimension][y_dimension];
        square_is_covered = new boolean [x_dimension][y_dimension];
        
        // clear the board
        for (int x_index=0; x_index< x_dimension; x_index++){
            for (int y_index=0; y_index< y_dimension; y_index++){
               square_board[x_index][y_index]=0;
               square_is_covered[x_index][y_index]=true;
        }}// nested for
        total_num_mines = (DENSITY_PERCENTAGE*x_dimension*y_dimension)/100;
        // 20% random total
        int variance = rand.nextInt((2*total_num_mines)/10);
        if (0==rand.nextInt(1) )
        {
           total_num_mines+=variance;
         } else total_num_mines-=variance;
        
        int indexMine =0; 
        while (indexMine<total_num_mines)  {
            int pos_x = rand.nextInt(x_dimension);
            int pos_y = rand.nextInt(y_dimension);
            if (-1!=square_board[pos_x][pos_y])
            { square_board[pos_x][pos_y]=-1;
              indexMine++;
            }
        }// while generating mines, and no duplicates
        
        for (int x_index=0; x_index< x_dimension; x_index++){
            for (int y_index=0; y_index< y_dimension; y_index++){
                // compute total of neighbout bombs
                if (-1 != square_board[x_index][y_index]) {
                    int neighbour_total=0;
                    for (int x_delta=-1; x_delta<2; x_delta++) {
                        for (int y_delta=-1; y_delta<2; y_delta++) {
                            int test_x=x_index + x_delta;
                            int test_y=y_index + y_delta;
                            if ( (0<=test_x) && (test_x<x_dimension)
                                    && (0<=test_y) && (test_y<y_dimension)
                                    && (-1 ==square_board[test_x][test_y] )
                                    ) {
                            neighbour_total++;
                            } // if a mine
                        }// nested for for window
                    }
                    square_board[x_index][y_index]=neighbour_total;
                }// if not a mine
               
        }}// nested for
    }
    
    /** 
    * Setter: Initialise the environment populating it with mines.
    * The difficulty level defines the number of vertical cells (this is the y_dimension).
    * The x_dimension is always 50% more then the y_dimension.
    * @param aLevel the difficulty level, this determines the size of the environment
    */
    public void setLevel(DifficultyLevels aLevel) {
        theLevel= aLevel;
        set_Board(theLevel);
    }
    
    /** 
    * Getter: What level has been set.
    * @return aLevel the difficulty level recorded for the environment.
    */
    public DifficultyLevels getLevel() {
        return theLevel;
    }
    
    /** 
    * A utility function that extracts the number of difficulty levels from the
    * enum DifficultyLevels so it is easy to add new difficulty levels only
    * adding a new row (and value) to the enum.
    * There may be better java programming trickery to do this, but it linear in the number of levels
    * @return a total count for difficulty levels.
    */
    public int totalNumberOfDifficultyLevels() {
        int totalCount=0;
        for (DifficultyLevels aLevelIndex:  DifficultyLevels.values()) {
            totalCount++;
        }
        return totalCount;
    }
    
    /** 
     * Getter: 
    * @return a number of mines.
    */
    public int getTotal_num_mines() {
        return total_num_mines;
    }
    
    /**
    * The active mines are those cells with -1
    * @return a the number of mines not flagged.
    */
    public int get_current_Total_num_mines() {
        int total =0;
        for (int x_index=0;x_index < x_dimension; x_index++ ) {
            for (int y_index=0; y_index < y_dimension; y_index++ ) {
             if (-1== square_board[x_index][y_index]) total++;
        }}
        
        return total;
    }
    
    /** 
    * Getter: 
    * @return the horizontal dimension (number of cells) in the environment
    */
    public int get_X_dimension() {
        return x_dimension;
    }
    
    /** 
    * Getter: 
    * @return the vertical dimension (number of cells) in the environment
    */
    public int get_Y_dimension() {
        return y_dimension;
    }
    
    /** 
    * The units are cell counts starting at 0 (zero).
    * @param x_pos the horizontal position left to right of a cell in the environment
    * @param y_pos the vertical position top to bottom of a cell in the environment
    * @return has the cell been marked earlier and flagged by the player
    */
    public boolean uncovered(int x_pos, int y_pos) {
        return !square_is_covered[x_pos][y_pos];
    }
    
    /** 
    * Action on the model when the user uncovers a cell.
    * @param x_pos the horizontal position left to right of a cell in the environment
    * @param y_pos the vertical position top to bottom of a cell in the environment
    */
    public void reveal(int x_pos, int y_pos) {
        square_is_covered[x_pos][y_pos]=false;
    }
    
        
    /** 
    * Action on the model when the user sets a flag  a cell.
    * A well place flag set to -2
    * A useless flag (not on a location with a mine) is set to -3
    * These values should probably be enums.
    * @param x_pos the horizontal position left to right of a cell in the environment
    * @param y_pos the vertical position top to bottom of a cell in the environment
    */
    public void setFlag(int x_pos, int y_pos) {
        reveal( x_pos,  y_pos);
        if (-1==square_board[x_pos][y_pos]) 
            square_board[x_pos][y_pos]=-2;
        else 
            square_board[x_pos][y_pos]=-3; 
    }
        
    /** 
    * Peek on the status of a cell in the model.
    * @param x_pos the horizontal position left to right of a cell in the environment
    * @param y_pos the vertical position top to bottom of a cell in the environment
    * @return the code for the status of the board/environment
    */
    public int getValue(int x_pos, int y_pos) {
        return square_board[x_pos][y_pos];
    }
    
    /** 
    * Test whether the status of a cell in the model is a mine (not flagged).
    * @param x_pos the horizontal position left to right of a cell in the environment
    * @param y_pos the vertical position top to bottom of a cell in the environment
    * @return true if an uncovered mine at the location
    */
    public boolean isMine(int x_pos, int y_pos) {
        return -1 == square_board[x_pos][y_pos];
    }
    
    /** 
    * Utility function to find IDs of cells adjacent to a cell.
    * The cell is given using a point with x,y components
    * @param p the horizontal position left to right of a cell in the environment
    * @return The list of those IDs as points of adjacent elements that have value zero are uncovered
    */
    public LinkedList<Point> adjacent(Point p) {
    LinkedList<Point>   result = new LinkedList<Point>();
    
     
     for (int x_delta=-1; x_delta<2; x_delta++) {
            for (int y_delta=-1; y_delta<2; y_delta++) {
                if (   
                        (0<=p.x+x_delta) && (p.x+x_delta<get_X_dimension())
                        && (0<=p.y+y_delta) && (p.y+y_delta<get_Y_dimension())
                        //&& (0== square_board[p.x+x_delta][p.y+y_delta]) // has no neighbout mines
                        //&& square_is_covered[p.x+x_delta][p.y+y_delta]
                        ) {
                            Point toQueue = new Point(p.x+x_delta,p.y+y_delta);
                            result.add(toQueue);
                }// if
     }} // nested for
     
    return result;
  }
    
}
