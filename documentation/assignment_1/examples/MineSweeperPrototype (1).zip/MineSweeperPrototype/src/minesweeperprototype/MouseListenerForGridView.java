
package minesweeperprototype;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.InputEvent;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * (c) 2020 Vlad Estivill-Castro
 * Model Solution for 2017-2018-2019 Assignment
 * 2805ICT/3815ICT/7805ICT Principles of Software Engineering / Design of Object Oriented Systems
 * Class to handle mouse clicks on the game arena and callback the view.
 */
public class MouseListenerForGridView extends MouseAdapter{
    
    GridView myCallBackWithPointClick;
    
    public MouseListenerForGridView(GridView theDrawing) {
        myCallBackWithPointClick= theDrawing;
    }
    
    private static boolean isRightClick(MouseEvent e) {
    return (e.getButton()==MouseEvent.BUTTON3 ||
            (System.getProperty("os.name").contains("Mac OS X") &&
                    (e.getModifiers() & InputEvent.BUTTON1_MASK) != 0 &&
                    (e.getModifiers() & InputEvent.CTRL_MASK) != 0));
      }
    
    public void mouseClicked(MouseEvent e) { 
	int x = e.getX(); 
	int y = e.getY();
        if (isRightClick(e)) {
            // right click, user sets flag
              myCallBackWithPointClick.setFlagWithClick(x,y);
        } else {
              myCallBackWithPointClick.setPointWithClick(x,y);
        }
    }
    
}
