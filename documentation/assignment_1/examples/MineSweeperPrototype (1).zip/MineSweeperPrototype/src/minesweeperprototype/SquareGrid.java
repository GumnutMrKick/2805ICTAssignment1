
package minesweeperprototype;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Shape;
import java.awt.geom.Ellipse2D;

/**
 * (c) 2020 Vlad Estivill-Castro
 * Model Solution for 2017-2018-2019 Assignment
 * 2805ICT/3815ICT/7805ICT Principles of Software Engineering / Design of Object Oriented Systems
 * Class to draw squares, covered an uncovered. Thus with numbers or icons for flags or mines.
 */
public class SquareGrid {
    
    private static int side_length=20;
    private static int border_in_pixels;
    
    	public static void setSide(int side) {
		side_length=side;
	}
        
        public static void setBorder(int width) {
		border_in_pixels=width;
	}
        
        public static int getSide() {
		return side_length;
	}
        
    public static Polygon logic_square_by_corner (int x0, int y0) {
        
	int physical_x = x0 + border_in_pixels;
        int physical_y = y0 + border_in_pixels;
        int[] boundary_x, boundary_y;
        
        boundary_x = new int[] {physical_x,physical_x+side_length,physical_x+side_length,physical_x};
        boundary_y = new int[] {physical_y,physical_y,physical_y+side_length,physical_y+side_length};
        
        return new Polygon(boundary_x,boundary_y,4);
    }
    
    	public static void drawSquare(int i, int j, Graphics2D g2) {
		int x = i * side_length;
		int y = j * side_length;
		Polygon poly = logic_square_by_corner(x,y);
		g2.setColor(Color.LIGHT_GRAY);
		g2.fillPolygon(poly);
		g2.setColor(Color.BLACK);
		g2.drawPolygon(poly);
	}
        
        private static Point getCenter(Polygon aPolygon){
            int theXPoints [] = aPolygon.xpoints;
            int theYPoints [] = aPolygon.ypoints;
            int centerX =0;
            int centerY =0;
            for (int i =0; i< theXPoints.length; i++){
                centerX+=theXPoints[i];
                centerY+=theYPoints[i];
            }
            Point p = new Point(centerX/theXPoints.length, centerY/theXPoints.length);
            return p;
        }
        
        public static void drawUncoveredSquare(int i, int j,int  value, Graphics2D g2) {
		int x = i * side_length;
		int y = j * side_length;
		Polygon poly = logic_square_by_corner(x,y);
                 Point center = getCenter(poly);
                if (value<0) {
                    if (-1==value) {// a bomb
                        g2.setColor(Color.RED);
                        g2.fillPolygon(poly);
                        g2.setColor(Color.BLACK);
                        Shape circle = new Ellipse2D.Double(center.x-side_length/4,
                                            center.y-side_length/4, 
                                            side_length/2,
                                            side_length/2 );
                        g2.fill(circle);
                    }
                        
                    if ((-2==value) || (-3==value)) { //player marked a flag
                        g2.setColor(Color.GREEN);
                        g2.fillPolygon(poly);
                        g2.setColor(Color.BLACK);
                        Shape base = new Rectangle(center.x-side_length/4,
                                            center.y+side_length/4, 
                                            side_length/2,
                                            side_length/4 );
                        g2.fill(base);
                        Shape post = new Rectangle(center.x-side_length/8,
                                            center.y-side_length/4, 
                                            side_length/4,
                                            side_length/2 );
                        g2.fill(post);
                        g2.setColor(Color.BLUE);
                        Shape circle = new Ellipse2D.Double(center.x-side_length/4,
                                            center.y-side_length/2, 
                                            side_length/2,
                                            side_length/2 );
                        g2.fill(circle);
                    }
                } else { 
                    g2.setColor(Color.WHITE);
		    g2.fillPolygon(poly); 
                    if (value>0) {
                        switch (value) {
                            case 1: g2.setColor( Color.BLUE ); break;
                            case 2: g2.setColor( Color.GREEN ); break;
                            case 3: g2.setColor( Color.RED ); break;
                            case 4: g2.setColor( Color.DARK_GRAY ); break;
                            case 5: g2.setColor( Color.MAGENTA ); break;
                            case 6: g2.setColor( Color.YELLOW ); break;
                            case 7: g2.setColor( Color.CYAN ); break;
                            case 8: g2.setColor( Color.PINK ); break;
                        }
                        g2.drawString(""+value, x+side_length/2, y+border_in_pixels+side_length); 
                    }
                } // not a mine
                g2.setColor(Color.BLACK);
		g2.drawPolygon(poly);
	}// drawUncoveredSquare
}
