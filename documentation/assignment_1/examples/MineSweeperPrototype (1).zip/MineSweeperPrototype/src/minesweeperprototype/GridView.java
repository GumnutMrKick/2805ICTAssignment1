/**
 * (c) 2020 Vlad Estivill-Castro
 * Model Solution for 2017-2018-2019 Assignment
 * 2805ICT/3815ICT/7805ICT Principles of Software Engineering / Design of Object Oriented Systems
 */

package minesweeperprototype;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import javax.swing.JPanel;


/**
 * (c) 2020 Vlad Estivill-Castro
 * Model Solution for 2017-2018-2019 Assignment
 * 2805ICT/3815ICT/7805ICT Principles of Software Engineering / Design of Object Oriented Systems
 * Class to draw the environment of a square grid.
 */
public class GridView extends JPanel{
    private static final int[] THE_SIDE_SIZE={40,30,20};
    private static final int HEIGHT_IN_PIXELS=500;
    
    private static final int BORDER_IN_PIXELS=5;
    final static Color COLOUR_BACKGROUND =  Color.LIGHT_GRAY;
    
    private boolean enabled;
    
    Point recordClickID;
    GlobalModel theModel;
    MineSweeperPrototype thePseudoController;
    
    /**
     * Constructor
     * @param aModel reference back to the model to invoke actions on it
     * @param pseudoController reference back to the pseudoController that holds some widgets that need updating
     */		
    public GridView(GlobalModel aModel, MineSweeperPrototype pseudoController)
		{	enabled=true;
			setBackground(COLOUR_BACKGROUND);

                        theModel= aModel;
                        thePseudoController=pseudoController;
 
			MouseListenerForGridView ml = new MouseListenerForGridView(this);            
			addMouseListener(ml);
		}
                
                /**
                 * Adopt a new model (environment) and let the garbage collector take care of the previous one.
                 * @param aModel the new model, a new instance of a game board.
                 */
                public void updateModel(GlobalModel aModel){
                    theModel= aModel;
                }
                
                 /**
                 * Using our own to disable user clicks on the environment.
                 * @param set_enabled if true the panel of the environment becomes active
                 */
                public void mySetEnabled(boolean set_enabled){
                    enabled= set_enabled;
                }
                
                /**
                 * @return default hight in pixels (not cells)
                 */
                public int grid_height_in_pixels () {
                    return HEIGHT_IN_PIXELS;
                }
                
                /**
                * Obtain click location of a players
                * @return Obtain the cell id as coordinates in a point in cells not pixels
                */
                private Point clickLocation (int x_on_board, int y_on_board) {
                    int x_noborder = x_on_board-BORDER_IN_PIXELS;
                    int y_noborder = y_on_board-BORDER_IN_PIXELS;
                    int x_id = x_noborder/SquareGrid.getSide();
                    int y_id = y_noborder/SquareGrid.getSide();
                    
                    recordClickID = new Point(x_id ,y_id);
                    return  recordClickID;
                }
                
                /**
                 * A call back from the event listener, will notify the model the user's attempt
                 * to flag a cell.
                 * Guarded by the our enabled condition.
                 * Repaints the environment to reflect changes.
                 * @param x_on_board cell coordinate horizontally left to right
                 * @param y_on_board cell coordinate vertically top to bottom
                 */
                public void setFlagWithClick(int x_on_board, int y_on_board) {
                    if (enabled) {
                    Point aClickLocation = clickLocation(x_on_board,  y_on_board);
                    theModel.setFlag(aClickLocation.x,aClickLocation.y);
                    if (-2==theModel.getValue(aClickLocation.x,aClickLocation.y)) { 
                        // the user signals a mine correctly
                        thePseudoController.updateTotalMinesDisplay(theModel.get_current_Total_num_mines());
                        if (0== theModel.get_current_Total_num_mines()) {
                            thePseudoController.gameOver(true);
                        }
                    }
                    repaint();
                    }
                }
                
                 /**
                 * A call back from the event listener, will notify the model the user's attempt
                 * to uncover a cell.
                 * Guarded by the our enabled condition.
                 * Calls the flooding algorithm if user hits a cell of value zero.
                 * Repaints the environment to reflect changes.
                 * @param x_on_board cell coordinate horizontally left to right
                 * @param y_on_board cell coordinate vertically top to bottom
                 */
                public void setPointWithClick(int x_on_board, int y_on_board) {
                    if (enabled) {
                    Point aClickLocation = clickLocation(x_on_board,  y_on_board);
                    theModel.reveal(aClickLocation.x,aClickLocation.y);
                    if (0==theModel.getValue(aClickLocation.x,aClickLocation.y)) {
                            // flooding algorithm
                            FloodUncoveringZero runFlooding = new FloodUncoveringZero(theModel, aClickLocation);
                        } 
                    
                    if (-1==theModel.getValue(aClickLocation.x,aClickLocation.y)) {
                            // REVEAL mines
                            for (int i=0;i<theModel.get_X_dimension();i++) {
				for (int j=0;j<theModel.get_Y_dimension();j++) {
                                    if (! theModel.uncovered(i,j)) {
                                        int value = theModel.getValue(i,j);
                                        if (-1==value) {
                                            theModel.reveal(i,j);
                                        }
                                    }// uncovered
				}
			    }// nested for
                            // stop the clock
                            thePseudoController.gameOver(false);
                        }// game over
                    repaint();
                        
                    }
                }
                
                 /**
                  *  Draw the environment
                  */
                public void paintComponent(Graphics g)
		{
                    Graphics2D g2 = (Graphics2D)g;
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    g.setFont(new Font("TimesRoman", Font.PLAIN, 20));
                    super.paintComponent(g2);
                    
                    SquareGrid.setSide(HEIGHT_IN_PIXELS/theModel.get_Y_dimension());
                    SquareGrid.setBorder(BORDER_IN_PIXELS);
           
                    //draw base grid    
                    for (int i=0;i<theModel.get_X_dimension();i++) { 
                        for (int j=0;j<theModel.get_Y_dimension();j++) {
                            SquareGrid.drawSquare(i,j,g2);
                        }
                    }   
                        
                     //redraw uncovered
		     for (int i=0;i<theModel.get_X_dimension();i++) {
				for (int j=0;j<theModel.get_Y_dimension();j++) {
                                    if (theModel.uncovered(i,j)) {
                                        int value = theModel.getValue(i,j);
                                        SquareGrid.drawUncoveredSquare(i,j,value,g2);
                                    }// uncovered
				}
			}
                }
}
