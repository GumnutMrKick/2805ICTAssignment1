package minesweeperprototype;

import java.io.IOException;
import java.awt.Dimension;
import javax.swing.Timer;
import java.awt.event.*;
import java.awt.BorderLayout;
import java.awt.Color;

/**
 * (c) 2020 Vlad Estivill-Castro
 * Model Solution for 2017-2018-2019 Assignment
 * 2805ICT/3815ICT/7805ICT Principles of Software Engineering / Design of Object Oriented Systems
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see www.gnu.org/licenses.
 * @see<a href="https://www.gnu.org/licenses"> https://www.gnu.org/licenses </a>.
 * 
 * Class sets up the widgets and acts as a pseudo controller.
 */
public class MineSweeperPrototype extends javax.swing.JFrame {
    
    /**
     * The default constants
     */
    private static final int DIGIT_WIDTH=35;
    private static final int PIXEL_BUFFER=10;
    private static final int TIME_LEFT=201;
    
    private static final String NOVICE_LEVEL="Novice";
    private static final String COMPETENT_LEVEL="Competent";
    private static final String EXPERT_LEVEL="Expert";
    
    /**
     * The components/widgets stay in the realm of the Frame
     */
    private javax.swing.JMenuBar jMenuBarTop;
    private javax.swing.JMenu jMenuEnvironment;
    private javax.swing.JMenuItem jMenuSquare;
    private javax.swing.JMenuItem jMenuHexagon;
    private javax.swing.JMenuItem jMenuGraph;
    private javax.swing.JMenu jMenuLevel;
    private javax.swing.JMenu jMenuReset;
    private javax.swing.JMenuItem jMenuItemReset;
    
    private javax.swing.JMenuItem[] jMenuItemLevel;
    private javax.swing.JMenuItem jMenuNovice;
    private javax.swing.JMenuItem jMenuCompetent;
    private javax.swing.JMenuItem jMenuExpert;
    
    private javax.swing.JPanel JPanelGameArea; // Infor Area and PlayArea Top to  bottom
    private javax.swing.JPanel JPanelInfoArea; // the time, face and score Left to right
    private javax.swing.JPanel JPanelGameScore;
    
    private javax.swing.JPanel JPanelTimeLeft;
    
    /**
    * Where we draw the environment
    */
    GridView JPanelPlayArea;
    
    private javax.swing.JLabel JLabelUnitsSeconds;
    private javax.swing.JLabel JLabelTensSeconds;
    private javax.swing.JLabel JLabelHundredSeconds;
    
    private javax.swing.JButton JButtonFace;
    private javax.swing.JLabel JLabelUnitsMines;
    private javax.swing.JLabel JLabelTensMines;

    
    private  Images theimages;
    
     /**
     * These data elements are probably the Model
     */
    private javax.swing.Timer timerSeconds;
    private int timeleft;
    private GlobalModel theModel;
    
     /**
     * Event handler
     * @param aLevel the user choice of level
     */
    private void jMenuItemSetLevel( GlobalModel.DifficultyLevels aLevel ) {
        theModel.setLevel(aLevel);
        JPanelPlayArea.repaint();
    }
    
    private void JButtonFaceStart(java.awt.event.ActionEvent evt) {
                 // TIMER
         timeleft = TIME_LEFT;
         timerSeconds.start();
         JPanelPlayArea.mySetEnabled(true);
         JButtonFace.setBackground(Color.GRAY);
         JButtonFace.setEnabled(false);
         jMenuSquare.setEnabled(false);
         jMenuHexagon.setEnabled(false);
         jMenuGraph.setEnabled(false);
        
         for (GlobalModel.DifficultyLevels aLevelIndex: GlobalModel.DifficultyLevels.values()) {
             jMenuItemLevel[aLevelIndex.value].setEnabled(false);
            }
         updateTotalMinesDisplay(theModel.getTotal_num_mines());
    }
    
    private void JMenuItemReset() {
        JButtonFace.setEnabled(true);
        JPanelPlayArea.mySetEnabled(false);
        jMenuSquare.setEnabled(true);
        jMenuHexagon.setEnabled(true);
        jMenuGraph.setEnabled(true);
        JButtonFace.setBackground(Color.YELLOW);
        JButtonFace.setIcon(theimages.startIcon() );
        jMenuReset.setEnabled(false);
        
        for (GlobalModel.DifficultyLevels aLevelIndex: GlobalModel.DifficultyLevels.values()) {
             jMenuItemLevel[aLevelIndex.value].setEnabled(true);
            }
        
        timeleft = 0;
        updateMySecondsDisplay();
        theModel = new GlobalModel( );
        JPanelPlayArea.updateModel(theModel);
        JPanelPlayArea.repaint();
        updateTotalMinesDisplay(0);
    }
    
     /**
     * callback to act when a mine is uncovered by the user or no more mines to localise
     * @param aWin was it a win? (otherwise the player lost)
     */
    public  void gameOver(boolean aWin){
        timerSeconds.stop();
        JButtonFace.setBackground(Color.YELLOW);
        if (aWin) JButtonFace.setIcon(theimages.winIcon() );
        else JButtonFace.setIcon(theimages.gameOverIcon() );
        JPanelPlayArea.mySetEnabled(false);
        jMenuReset.setEnabled(true);
    }
    
    /**
     * Execution starter
     * Finds platform independent UI manager
     * @param args the command line arguments are ignored
     */
    public static void main(String[] args)  {
        System.out.println(" (c) 2020 Vlad Estivill-Castro");
        	        try {
	            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
	                if ("Nimbus".equals(info.getName())) {
	                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
	                    break;
	                }
	            }
	        } catch (ClassNotFoundException ex) {
	            java.util.logging.Logger.getLogger(MineSweeperPrototype.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (InstantiationException ex) {
	            java.util.logging.Logger.getLogger(MineSweeperPrototype.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (IllegalAccessException ex) {
	            java.util.logging.Logger.getLogger(MineSweeperPrototype.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
	            java.util.logging.Logger.getLogger(MineSweeperPrototype.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
	        }
			
	        /* Create and display the form */
	        java.awt.EventQueue.invokeLater(new Runnable() {
	           public void run() {
	                new MineSweeperPrototype().setVisible(true);
	             }
	         });
    }
    
     /**
     *  Constructor initialises GUI by setting up widgets/ components
     */
     public MineSweeperPrototype() {
	        initComponents();
	    }
     
    private void updateMySecondsDisplay() {
              timeleft= timeleft > 0 ? timeleft-1: 0;
              int units = timeleft %10;
              int tens = ((timeleft %100) - units) /10;
              int hundreds = (((timeleft %1000) - units) - tens) /100;
              JLabelUnitsSeconds.setIcon(theimages.digitIcon(units));
              JLabelTensSeconds.setIcon(theimages.digitIcon(tens));
              JLabelHundredSeconds.setIcon(theimages.digitIcon(hundreds));
     }
    
    /**
    * theView (GridView) calls back here to update the number of mines
    * because this class actually holds the widgets to display the remaining mines
    * @param theNumberOfMines value of mines to display
    */
    public void updateTotalMinesDisplay(int theNumberOfMines) {
        int theNumberOfMinesInUnits = theNumberOfMines %10;
         int theNumberOfMinesInTens = (theNumberOfMines /10) % 10;
         JLabelUnitsMines.setIcon(theimages.digitIcon(theNumberOfMinesInUnits));
         JLabelTensMines.setIcon(theimages.digitIcon(theNumberOfMinesInTens));
    }
    
    /**
     *  Set all the components/widgets
     */
     private void initComponents() {
         // create the widgets and fill them
         
         timerSeconds = new  javax.swing.Timer(1000, new ActionListener() {
          public void actionPerformed(ActionEvent e) {
              updateMySecondsDisplay();
          }
       });
         try {
             
         theimages = new Images(DIGIT_WIDTH);
         timeleft = TIME_LEFT;
         int digit_height =theimages.offIcon() .getIconHeight();
         
         theModel = new GlobalModel( );
         
         JButtonFace = new javax.swing.JButton(theimages.startIcon() );
         
         JButtonFace.setBackground(Color.YELLOW);
         JButtonFace.addActionListener(new java.awt.event.ActionListener() {
	             public void actionPerformed(java.awt.event.ActionEvent evt) {
	                 JButtonFaceStart(evt);
	             }
	         });
         
         JLabelUnitsMines = new javax.swing.JLabel(theimages.offIcon() );
         JLabelTensMines  = new javax.swing.JLabel(theimages.offIcon() );
         JLabelUnitsMines.setPreferredSize(new Dimension(DIGIT_WIDTH, digit_height));
         JLabelTensMines.setPreferredSize(new Dimension(DIGIT_WIDTH, digit_height));
         
         JLabelUnitsSeconds = new javax.swing.JLabel (theimages.offIcon() );
         JLabelTensSeconds = new javax.swing.JLabel (theimages.offIcon() );
         JLabelHundredSeconds = new javax.swing.JLabel (theimages.offIcon() );
         JLabelUnitsSeconds.setPreferredSize(new Dimension(DIGIT_WIDTH, digit_height));
         JLabelTensSeconds.setPreferredSize(new Dimension(DIGIT_WIDTH, digit_height));
         JLabelHundredSeconds.setPreferredSize(new Dimension(DIGIT_WIDTH, digit_height));
         
         jMenuBarTop = new javax.swing.JMenuBar();
         jMenuEnvironment  = new javax.swing.JMenu();
         jMenuLevel  = new javax.swing.JMenu();
         JPanelGameArea = new  javax.swing.JPanel();
         JPanelGameScore = new javax.swing.JPanel();
         
         //JPanelPlayArea = new GridView(theModel);
         JPanelPlayArea = new GridView(theModel,this);
         int heightInPixels = JPanelPlayArea.grid_height_in_pixels();
         int widthInPixels = heightInPixels+heightInPixels/2;
         
         JPanelPlayArea.setPreferredSize(new Dimension(widthInPixels,heightInPixels+PIXEL_BUFFER));
         JPanelTimeLeft = new javax.swing.JPanel();
         JPanelInfoArea = new javax.swing.JPanel();
         
         JPanelTimeLeft.add(JLabelHundredSeconds);
         JPanelTimeLeft.add(JLabelTensSeconds);
         JPanelTimeLeft.add(JLabelUnitsSeconds);
         
         JPanelGameScore.add(JLabelTensMines);
         JPanelGameScore.add(JLabelUnitsMines);
         
         JPanelInfoArea.setLayout(new BorderLayout());
         JPanelInfoArea.add(JPanelTimeLeft,BorderLayout.WEST);
         JPanelInfoArea.add(JButtonFace, BorderLayout.CENTER);
         JPanelInfoArea.add(JPanelGameScore,BorderLayout.EAST);
         
         JPanelGameArea.setLayout(new BorderLayout());
         JPanelGameArea.add(JPanelInfoArea,BorderLayout.NORTH);
         JPanelGameArea.add(JPanelPlayArea,BorderLayout.SOUTH);
         
         jMenuSquare = new javax.swing.JMenuItem();
         jMenuSquare.setText("Squared Grid Environment");
         
         jMenuHexagon = new javax.swing.JMenuItem();
         jMenuHexagon.setText("Hexagonal Grid Environment");
         
         jMenuGraph = new javax.swing.JMenuItem();
         jMenuGraph.setText("Topological (Graph) Environment");
         
         jMenuEnvironment.setText("Environment");
         jMenuEnvironment.add(jMenuSquare);
         jMenuEnvironment.add(jMenuHexagon);
         jMenuEnvironment.add(jMenuGraph);
         
         jMenuLevel.setText("Level");
         
         jMenuItemLevel = new javax.swing.JMenuItem[theModel.totalNumberOfDifficultyLevels()];
         for (GlobalModel.DifficultyLevels aLevelIndex: GlobalModel.DifficultyLevels.values()) {
             jMenuItemLevel[aLevelIndex.value]=jMenuNovice = new javax.swing.JMenuItem();
             jMenuItemLevel[aLevelIndex.value].setText(aLevelIndex.toString());
             jMenuItemLevel[aLevelIndex.value].addActionListener(new java.awt.event.ActionListener() {
	             public void actionPerformed(java.awt.event.ActionEvent evt) {
	                 jMenuItemSetLevel(aLevelIndex);
	             }
	         });
             jMenuLevel.add(jMenuItemLevel[aLevelIndex.value]);
         } // For difficulty levels
         
         jMenuItemReset = new javax.swing.JMenuItem();
         jMenuReset = new javax.swing.JMenu();
         
         jMenuReset.setText("Reset");
         jMenuItemReset.setText("Reset game");
         jMenuReset.add(jMenuItemReset);
         jMenuItemReset.addActionListener(new java.awt.event.ActionListener() {
	             public void actionPerformed(java.awt.event.ActionEvent evt) {
	                 JMenuItemReset();
	             }
	         });
         
         jMenuBarTop.add(jMenuEnvironment);
         jMenuBarTop.add(jMenuLevel);
         jMenuBarTop.add(jMenuReset);
         
         this.add(JPanelGameArea);
         
         // should be the same setting at start than after reset
         JMenuItemReset();
         
         setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
         
         this.setTitle("Three Worlds Mine-Sweeper (c) 2020 Vlad Estivill-Castro");
         this.setJMenuBar(jMenuBarTop);
	 this.setSize(2*PIXEL_BUFFER + widthInPixels,
                        60+2*jMenuBarTop.getHeight()+
                      2*PIXEL_BUFFER + heightInPixels+ digit_height);
         this.setResizable(false);
	 this.setLocationRelativeTo( null );
	 this.setVisible(true);
                 
        }  catch (IOException e) {
             e.printStackTrace();
        }
     }
}
