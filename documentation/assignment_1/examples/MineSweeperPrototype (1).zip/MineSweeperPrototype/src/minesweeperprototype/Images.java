/**
 * (c) 2020 Vlad Estivill-Castro
 * Model Solution for 2017-2018-2019 Assignment
 * 2805ICT/3815ICT/7805ICT Principles of Software Engineering / Design of Object Oriented Systems
 */
package minesweeperprototype;

import javax.swing.ImageIcon;
import java.awt.image.BufferedImage;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.File;
import javax.imageio.ImageIO;
import java.io.IOException;

/**
 * (c) 2020 Vlad Estivill-Castro
 * Model Solution for 2017-2018-2019 Assignment
 * 2805ICT/3815ICT/7805ICT Principles of Software Engineering / Design of Object Oriented Systems
 * Class load images (digits) as scaled icons.
 */
public class Images {
    
    private static final int NUM_DIGITS = 10;
    private static final String OFF = "Off.jpg";
    private static final String ZERO = "Zero.jpg";
    private static final String ONE = "One.jpg";
    private static final String TWO = "Two.jpg";
    private static final String THREE = "Three.jpg";
    private static final String FOUR = "Four.jpg";
    private static final String FIVE = "Five.jpg";
    private static final String SIX = "Six.jpg";
    private static final String SEVEN = "Seven.jpg";
    private static final String EIGHT = "Eight.jpg";
    private static final String NINE = "Nine.jpg";
    
    private static final String WIN = "Happy.jpg";
    private static final String GAME_OVER = "Sad.jpg";
    private static final String START = "Start.jpg";

    private static final float XY_DIGIT_RATIO = 1.5f;
    
    // there are 11 images, the digits plus off (indexed as 10
    private final ImageIcon theDigits[] = new ImageIcon[NUM_DIGITS+1];
    private final ImageIcon win;
    private final ImageIcon game_over;
    private final ImageIcon start;
    private final String intToFilename[] = {ZERO,ONE,TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE,OFF};
    
    private ImageIcon scaleImageToIcon  (int digetWidthInPixels, int digetHeightInPixels, String theFileName) throws IOException  {
        File theDirectory = new File(System.getProperty("user.dir"));
        // TODO. This Path is POSIX dependant
	BufferedImage sourceImage  = ImageIO.read(new File(theDirectory.getAbsolutePath()+"/"+theFileName));
        BufferedImage targetImg = new BufferedImage(digetWidthInPixels, digetHeightInPixels, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = targetImg.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(sourceImage, 0, 0, digetWidthInPixels, digetHeightInPixels, null);
        g2.dispose();
        
        ImageIcon result = new ImageIcon(targetImg);
        
        return result;
}
    
    public Images(int digetWidthInPixels) throws IOException {
        float float_digetHeightInPixels = XY_DIGIT_RATIO*digetWidthInPixels;
        int digetHeightInPixels = (int) float_digetHeightInPixels;
        
        // face is in a square Icon
        win = scaleImageToIcon(digetHeightInPixels,digetHeightInPixels, WIN);
        game_over = scaleImageToIcon(digetHeightInPixels,digetHeightInPixels, GAME_OVER);
        start = scaleImageToIcon(digetHeightInPixels,digetHeightInPixels, START);
        
        theDigits[10]=scaleImageToIcon(digetWidthInPixels,digetHeightInPixels, OFF);
        for (int i=0; i<NUM_DIGITS; i++)
              theDigits[i]=scaleImageToIcon(digetWidthInPixels,digetHeightInPixels, intToFilename[i]);
	}
    
    public ImageIcon gameOverIcon() {
      return game_over;
      }
    
    public ImageIcon winIcon() {
      return win;
      }
    
    public ImageIcon startIcon() {
      return start;
      }
    
    public ImageIcon offIcon() {
      return theDigits[10];
      }
    
    public ImageIcon digitIcon(int digit) {
      return theDigits[digit];
      }
}
