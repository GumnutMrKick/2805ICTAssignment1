package minesweeperprototype;

import java.util.LinkedList;
import java.util.Iterator;
import java.util.Queue;
import java.awt.Point;

/**
 * (c) 2020 Vlad Estivill-Castro
 * Model Solution for 2017-2018-2019 Assignment
 * 2805ICT/3815ICT/7805ICT Principles of Software Engineering / Design of Object Oriented Systems
 * Class that caries the job of computing a region of cells with value zero
 * and its boundary. It is a variation of Dijstra's algorithm (or breadth first search)
 * using a queue to explore the adjacent node.
 */
public class FloodUncoveringZero {
    
/**
 * Constructor that implements the flooding algorithm.
 * Treats the environment as a graph, and should be generic for different types of environments.
 * It requires a model to  1) obtain adjacent nodes to a node in the environment.
 * 2) obtain the value of the node in the environment
 * @param aModel the model where to perform breadth first search
 * @param startID the starting point to flood the region of zero values.
 */
    public FloodUncoveringZero(GlobalModel aModel, Point startID ) {
        Queue<Point> queue = new LinkedList<Point>();
        Queue<Point> revealed = new LinkedList<Point>();
        
        LinkedList<Point>   start = aModel.adjacent(startID);
        Iterator it = start.iterator();
        while(it.hasNext()){
            Point thePoint = (Point) it.next();
            if (0==aModel.getValue(thePoint.x, thePoint.y)) //only propage from zero
                 queue.add(  thePoint   );
        }
        
        while (!queue.isEmpty()){
            Point thePoint = queue.remove();
            revealed.add(thePoint);
            aModel.reveal(thePoint.x, thePoint.y);
            LinkedList<Point>   others = aModel.adjacent(thePoint);
            
            Iterator it_others = others.iterator();
            while(it_others.hasNext()){
                    Point thePossiblePoint = (Point) it_others.next();
                    if (    (!queue.contains(thePossiblePoint) )
                            &&(!revealed.contains(thePossiblePoint))
                            && (0==aModel.getValue(thePossiblePoint.x, thePossiblePoint.y))
                       ) 
                    { queue.add(  thePossiblePoint   );  }
                    aModel.reveal(thePossiblePoint.x, thePossiblePoint.y);
                }// adding adjancet elements not in tje queue
        } // while neighbours unexplored
    }
}
